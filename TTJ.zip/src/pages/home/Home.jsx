import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import "./Home.css";
import Sidenav from "../../components/Sidenav";
import Navbar from "../../components/Navbar";
import { Link } from "react-router-dom";
import { FaPlus } from "react-icons/fa6";

function Home() {
  return (
    <>
      <div className="home">
        <Navbar />
        <Box height={70} />

        <Box sx={{ display: "flex" }}>
          <Sidenav />
          <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
            <div className="box">
              <div className="box_header">
                <h3> Talabalar</h3>
                <FaPlus />
              </div>
              <div className="box_body">
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Barchasi</p>
                </Link>
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Kutmoqda</p>
                </Link>
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Bezildi</p>
                </Link>{" "}
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Chiqib ketdi</p>
                </Link>
              </div>
            </div>
            <div className="box">
              <div className="box_header">
                <h3> Xonalar</h3>
                <FaPlus />
              </div>
              <div className="box_body">
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Barchasi</p>
                </Link>
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Kutmoqda</p>
                </Link>
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Bezildi</p>
                </Link>{" "}
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Chiqib ketdi</p>
                </Link>
              </div>
            </div>
            <div className="box">
              <div className="box_header">
                <h3> To'lovlar</h3>
                <FaPlus />
              </div>
              <div className="box_body">
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Barcha to'lovlar</p>
                </Link>
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>qarzdorlar</p>
                </Link>
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>haqdorlar</p>
                </Link>{" "}
                <Link className="smalL_box">
                  <div className="icon">
                    <img src="" alt="" />
                  </div>
                  <p>Chiqib ketdi</p>
                </Link>
              </div>
            </div>
          </Box>
        </Box>
      </div>
    </>
  );
}

export default Home;
